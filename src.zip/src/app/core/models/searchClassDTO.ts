import { searchDTO } from "./searchDTO";

export interface SearchClassDTO extends searchDTO{}