import { searchDTO } from "./searchDTO";

export interface SearchDepartmentDTO extends searchDTO{}