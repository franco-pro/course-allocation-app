import { searchDTO } from "./searchDTO";

export interface SearchLevelDTO extends searchDTO{}