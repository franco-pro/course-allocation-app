import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogModule
} from '@angular/material/dialog';

import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';

import { TeachersService } from '../../teachers/services/teachers.service';
import { SubjectsService } from '../../matieres/services/matiere.service';
import { ClassesService } from '../../classes/services/classes.service';
import { AssignmentProposalService } from '../services/proposal.service';
import { SchoolYear } from '../../../core/models/year.model';
import { Classe } from '../../../core/models/classe.model';
import { Subject } from '../../../core/models/matiere.model';
import { Teacher } from '../../../core/models/teachers.model';
import { SchoolYearsService } from '../../year/services/year.service';
import { AuthService } from '../../../core/auth/authService';

@Component({
  selector: 'app-proposal-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule
  ],
  templateUrl: './proposal-dialog.html',
  styleUrl: './proposal-dialog.scss'
})
export class ProposalDialogComponent implements OnInit {

  teachers: Teacher[] = [];
  subjects: Subject[] = [];
  classes: Classe[] = [];
  schoolYears: SchoolYear[] = [];
  
  // 1. Déclarez la propriété ici sans lui donner de valeur immédiatement
  form!: FormGroup; 

  constructor(
    private fb: FormBuilder,
    private teacherService: TeachersService,
    private subjectService: SubjectsService,
    private classService: ClassesService,
    private proposalService: AssignmentProposalService,
    private dialogRef: MatDialogRef<ProposalDialogComponent>,
    private readonly schoolYearService: SchoolYearsService,
    private authService: AuthService
,    @Inject(MAT_DIALOG_DATA) public data: any
  ){
    // 2. Initialisez impérativement le formulaire ICI dans le constructeur
    this.form = this.initializeForm();
  }

  private initializeForm() {
    return this.fb.group({
      enseignantMatricule: ['', Validators.required],
      matiereId: [null, Validators.required],
      anneeId: ['', Validators.required],
      classeIds: [[], Validators.required],
    });
  }

  ngOnInit() {
    // const currentUser = this.authService.getCurrentUser();
    // console.log('Current User:', currentUser);
//     if(currentUser){
//     this.form.patchValue({
//         proposedBy: currentUser.MATRICULE
//     });

// }
    this.teacherService.findAll().subscribe(res => this.teachers = res);
    this.subjectService.findAll().subscribe((res)=>{
      // console.log(res);
      this.subjects = res as Subject[];
    });
    this.classService.findAll().subscribe((res)=>{
      // console.log(res);
      this.classes = res as Classe[];
    });
    this.schoolYearService.findAll().subscribe(res=>{
      // console.log(res);
    this.schoolYears = res;
    if(res.length){
        this.form.patchValue({
            anneeId: res[res.length-1].id_annee
        });

    }

});

    if (this.data) {
      this.form.patchValue(this.data);
    }
  }

  save() {
    if (this.form.invalid) {
      console.log('Formulaire invalide', this.form);
      this.form.markAllAsTouched();
      return;
    }

    if (this.data) {
      // Mode Édition
      this.proposalService.update(this.data.id, this.form.value).subscribe(() => {
        this.dialogRef.close(true);
      });
    } else {
      this.proposalService.create(

        this.form.value

      ).subscribe(()=>{

        this.dialogRef.close(true);

      });
    }
  }
}
