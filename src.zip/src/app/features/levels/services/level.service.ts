import { Injectable } from '@angular/core';

import { ApiService } from '../../../core/services/api.service';

import { Level } from '../../../core/models/level.model';
import { SearchResponse } from '../../../core/models/searchResponse';
import { SearchLevelDTO } from '../../../core/models/searchLevelDTO';

@Injectable({

    providedIn:'root'

})

export class LevelsService extends ApiService{

    endpoint='levels';

    override findAll<T=Level>(){

        return super.findAll<T>(this.endpoint);

    }

    searchLevels(dto: SearchLevelDTO){
        return super.search<SearchResponse<Level>>(
            this.endpoint,
            dto
        );
    }

}