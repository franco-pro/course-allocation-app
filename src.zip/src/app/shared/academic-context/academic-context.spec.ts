import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcademicContext } from './academic-context';

describe('AcademicContext', () => {
  let component: AcademicContext;
  let fixture: ComponentFixture<AcademicContext>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AcademicContext],
    }).compileComponents();

    fixture = TestBed.createComponent(AcademicContext);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
