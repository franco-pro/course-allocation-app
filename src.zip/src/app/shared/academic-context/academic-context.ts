import { Component } from '@angular/core';

@Component({
  selector: 'app-academic-context',
  imports: [],
  templateUrl: './academic-context.html',
  styleUrl: './academic-context.scss',
})
export class AcademicContext {}
