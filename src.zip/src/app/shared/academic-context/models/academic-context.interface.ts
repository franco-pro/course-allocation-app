export interface AcademicContext {

    academicYearId?: string | null;

    departmentId?: number | null;

    levelId?: number | null;

    classId?: number | null;

    subjectId?: number | null;

    teacherMatricule?: string | null;

}