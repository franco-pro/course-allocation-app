import { Injectable, signal } from "@angular/core";
import { ClassesService } from "../../../features/classes/services/classes.service";
import { SubjectsService } from "../../../features/matieres/services/matiere.service";
import { TeachersService } from "../../../features/teachers/services/teachers.service";
import { SchoolYearsService } from "../../../features/year/services/year.service";
import { DepartmentsService } from "../../../features/departments/services/department.service";
import { LevelsService } from "../../../features/levels/services/level.service";
import { SelectOption } from "../models/academic-context-options.interface";
import { AcademicContextStore } from "../stores/academic-context.store";

@Injectable({
    providedIn:'root'
})
export class AcademicContextService {

    constructor(
        private store: AcademicContextStore,
        private academicYearService:SchoolYearsService,

        private departmentService:DepartmentsService,

        private classService:ClassesService,

        private subjectService:SubjectsService,

        private teacherService:TeachersService,
        private levelService: LevelsService

    ){}

     readonly years = signal<SelectOption<string>[]>([]);

    readonly departments = signal<SelectOption<number>[]>([]);

    readonly levels = signal<SelectOption<number>[]>([]);

    readonly classes = signal<SelectOption<number>[]>([]);

    readonly subjects = signal<SelectOption<number>[]>([]);

    readonly teachers = signal<SelectOption<string>[]>([]);

    
}