import { Injectable, computed, signal } from '@angular/core';
import { AcademicContext } from '../models/academic-context.interface';

@Injectable({
    providedIn: 'root'
})
export class AcademicContextStore {

    readonly context = signal<AcademicContext>({
        academicYearId: null,
        departmentId: null,
        levelId: null,
        classId: null,
        subjectId: null,
        teacherMatricule: null
    });

    update(partial: Partial<AcademicContext>) {

        this.context.update(current => ({
            ...current,
            ...partial
        }));

    }

    reset() {

        this.context.set({

            academicYearId: null,

            departmentId: null,

            levelId: null,

            classId: null,

            subjectId: null,

            teacherMatricule: null

        });

    }

    readonly selectedDepartment = computed(
        () => this.context().departmentId
    );

    readonly selectedClass = computed(
        () => this.context().classId
    );

    readonly selectedSubject = computed(
        () => this.context().subjectId
    );

    readonly selectedLevel = computed(
    () => this.context().levelId
);

readonly selectedTeacher = computed(
    () => this.context().teacherMatricule
);

readonly selectedAcademicYear = computed(
    () => this.context().academicYearId
);

}